#include "Perishable.h"
#include <iostream>
#include <iomanip>
using namespace std;
namespace ama {




	Perishable::Perishable() :Product('P') {

	}


	std::ostream& Perishable::write(std::ostream& out, int writeMode) const {
		bool condition = isClear() && !isEmpty();// true if no error and not in safe empty state
		Product::write(out, writeMode);
		if (!condition) // in error mode or in  empty state
		{
			// do nothing
		}
		else if (condition && writeMode == write_human)
		{
			out << setw(max_length_label) << right << "Expiry Date: " << expDate << endl;
		}
		else if (condition && writeMode == write_table)
		{
			out << " " << expDate << " |";
		}
		else if (condition && writeMode == write_condensed)
		{
			out << "," << expDate;
		}

		return out;


	}


	std::istream& Perishable::read(std::istream& in, bool interractive) {
		Product::read(in, interractive);
		Date tempexpl; // temp Date to check the input

		if (interractive)
		{

			cout << "Expiry date (YYYY/MM/DD):" << setw(max_length_label) << right << " ";
			in >> tempexpl;
			if (!tempexpl.isGood()) // if error
			{
				in.setstate(ios::failbit);

				switch (tempexpl.status())
				{

				case 1: // year
					message("Invalid Year in Date Entry");
					break;


				case 2: // error_mon
					message("Invalid Month in Date Entry");
					break;

				case 3: // error_day
					message("Invalid Day in Date Entry");
					break;
				case 5: // error input
					message("Invalid Date Entry");
					break;

				}
				//set to safe empty state
				*this = Perishable();
			}

			else
			{
				expDate = tempexpl; // store the date
			}

		}
		else // non interactive mod
		{

			if (in.get() == ',') // if there is a date
			{
				in >> expDate; // get the data
			}
			else
			{
				in.ignore(1, '\n'); // if is newline discharge the \n
			}

		}
		return in;
	}



} // end of namespace