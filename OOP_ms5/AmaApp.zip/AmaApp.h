#ifndef AMA_AMAAPP_H
#define AMA_AMAAPP_H

#include "iProduct.h"
#include "Perishable.h"

namespace ama {




	class AmaApp {

		char m_filename[256]; //Holds the name of the text file used to store the product information.

		iProduct * m_products[100];// An array of iProduct pointers

		int m_noOfProducts; //Number of products
		AmaApp(const AmaApp&) = delete;
		AmaApp& operator=(const AmaApp&) = delete;
		void pause() const;
		void listProducts() const;
	public:
		AmaApp(const char *);
		~AmaApp();
		int run();
		int menu() const;
		void loadProductRecords();
		iProduct* find(const char* sku) const;
		void addQty(iProduct* product);
		void addProduct(char tag);
	};

}//namespace

#endif // !AMA_AMAAPP_H
